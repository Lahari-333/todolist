/* ---------- Local Storage Persistance ---------- */
const storedRecords = JSON.parse(localStorage.getItem('taskflow_db') || '[]');
const storedUser = JSON.parse(localStorage.getItem('taskflow_user') || 'null');

function persistData() {
  localStorage.setItem('taskflow_db', JSON.stringify(state.records));
}

/* ---------- Mock SDK Fallback ---------- */
if (!window.dataSdk) {
  console.warn("data_sdk.js not found. Using local mock storage.");
  window.dataSdk = {
    create: async (data) => {
      const rec = { ...data, __backendId: uid(), id: uid() };
      state.records.push(rec);
      persistData(); // Save to browser storage
      return { isOk: true, data: rec };
    },
    update: async (id, data) => {
      const i = state.records.findIndex(r => r.__backendId === id || r.id === id);
      if(i > -1) state.records[i] = { ...state.records[i], ...data };
      persistData(); // Save to browser storage
      return { isOk: true };
    },
    delete: async (id) => {
      state.records = state.records.filter(r => r.__backendId !== id && r.id !== id);
      persistData(); // Save to browser storage
      return { isOk: true };
    }
  };
}

/* ---------- State ---------- */
const state = {
  route: storedUser ? 'app' : 'login', // Auto-route to app if logged in
  view: 'dashboard',       
  currentUser: storedUser,       
  records: storedRecords,  // Load records from browser storage
  filter: 'all',           
  editingTask: null,
  viewingTask: null,       
  showModal: false,
  loading: false,
  sidebarOpen: false,
};

const CONFIG = {
  app_name: 'TaskFlow',
  app_tagline: 'Organize work, together.',
  login_heading: 'Welcome back',
  login_subtitle: 'Sign in to your organization workspace.',
};

/* ---------- Utilities ---------- */
function uid() { return Math.random().toString(36).slice(2, 10); }

function toast(msg, type='success') {
  const t = document.getElementById('toast');
  const inner = document.getElementById('toastInner');
  inner.textContent = msg;
  inner.className = 'px-4 py-3 rounded-lg shadow-lg text-sm font-medium ' +
    (type === 'error' ? 'bg-rose-600 text-white' :
     type === 'info'  ? 'bg-slate-800 text-white' :
                        'bg-emerald-600 text-white');
  t.classList.remove('hidden');
  clearTimeout(toast._t);
  toast._t = setTimeout(()=> t.classList.add('hidden'), 2200);
}

function fmtDate(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const now = new Date();
  const diff = (now - d) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return Math.floor(diff/60) + 'm ago';
  if (diff < 86400) return Math.floor(diff/3600) + 'h ago';
  if (diff < 604800) return Math.floor(diff/86400) + 'd ago';
  return d.toLocaleDateString(undefined, { month:'short', day:'numeric' });
}

function escapeHtml(s){ 
  return (s||'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); 
}

/* ---------- Data helpers ---------- */
function users() { return state.records.filter(r => r.type === 'user'); }
function tasks() { return state.records.filter(r => r.type === 'task'); }
function logs()  { return state.records.filter(r => r.type === 'log'); }

function orgTasks() {
  if (!state.currentUser) return [];
  return tasks().filter(t => t.assignedOrg === state.currentUser.org);
}

function orgLogs() {
  if (!state.currentUser) return [];
  return logs()
    .filter(l => l.assignedOrg === state.currentUser.org)
    .sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));
}

function visibleTasks() {
  let list = orgTasks();
  if (state.currentUser.role !== 'admin' || state.filter === 'mine') {
    list = list.filter(t => t.createdByEmail === state.currentUser.email);
  }
  return list.sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));
}

async function logActivity(action, target) {
  await window.dataSdk.create({
    type: 'log',
    action,
    target,
    actor: state.currentUser.name,
    assignedOrg: state.currentUser.org,
    createdAt: new Date().toISOString(),
  });
}

function logIcon(action) {
  if (action.includes('created')) return 'plus';
  if (action.includes('updated') || action.includes('edited')) return 'pencil';
  if (action.includes('deleted')) return 'trash-2';
  if (action.includes('completed')) return 'check';
  return 'circle';
}

/* ---------- Render Root ---------- */
function render() {
  const root = document.getElementById('app');
  if (state.route === 'login' || state.route === 'signup') {
    root.innerHTML = renderAuth();
    bindAuth();
  } else {
    root.innerHTML = renderApp();
    bindApp();
  }
  lucide.createIcons();
}

/* ---------- Auth Screens ---------- */
function renderAuth() {
  const isLogin = state.route === 'login';
  return `
  <div class="h-full w-full flex">
    <div class="hidden lg:flex lg:w-1/2 relative overflow-hidden" style="background: linear-gradient(135deg,#0f172a 0%, #1e1b4b 50%, #312e81 100%);">
      <div class="absolute inset-0 opacity-30" style="background-image: radial-gradient(circle at 20% 30%, rgba(139,92,246,.4), transparent 40%), radial-gradient(circle at 80% 70%, rgba(59,130,246,.3), transparent 40%);"></div>
      <div class="relative z-10 p-12 flex flex-col justify-between text-white w-full">
        <div class="flex items-center gap-2">
          <div class="w-9 h-9 rounded-lg bg-violet-500 flex items-center justify-center">
            <i data-lucide="check-circle-2" class="w-5 h-5"></i>
          </div>
          <span class="text-xl font-bold">${escapeHtml(CONFIG.app_name)}</span>
        </div>
        <div>
          <h1 class="text-4xl font-bold leading-tight mb-4">Multi-tenant task<br/>management, simplified.</h1>
          <p class="text-slate-300 text-lg max-w-md">Each organization gets its own private workspace. Invite teammates, assign tasks, and keep work flowing.</p>
          <div class="mt-10 grid grid-cols-3 gap-4 max-w-md">
            ${[
              ['building-2','Isolated orgs'],
              ['shield-check','Role-based'],
              ['activity','Activity log']
            ].map(([i,t]) => `
              <div class="bg-white/5 border border-white/10 rounded-xl p-4">
                <i data-lucide="${i}" class="w-5 h-5 text-violet-300 mb-2"></i>
                <div class="text-sm font-medium">${t}</div>
              </div>
            `).join('')}
          </div>
        </div>
        <div class="text-xs text-slate-400">© ${new Date().getFullYear()} ${escapeHtml(CONFIG.app_name)}. ${escapeHtml(CONFIG.app_tagline)}</div>
      </div>
    </div>
    <div class="flex-1 flex items-center justify-center p-6 overflow-auto">
      <div class="w-full max-w-md fade-in">
        <div class="lg:hidden flex items-center gap-2 mb-8">
          <div class="w-9 h-9 rounded-lg bg-slate-900 flex items-center justify-center">
            <i data-lucide="check-circle-2" class="w-5 h-5 text-violet-400"></i>
          </div>
          <span class="text-xl font-bold text-slate-900">${escapeHtml(CONFIG.app_name)}</span>
        </div>
        <h2 class="text-3xl font-bold text-slate-900 mb-2">${isLogin ? escapeHtml(CONFIG.login_heading) : 'Create your workspace'}</h2>
        <p class="text-slate-500 mb-8">${isLogin ? escapeHtml(CONFIG.login_subtitle) : 'Start managing tasks with your team in minutes.'}</p>
        <form id="authForm" class="space-y-4">
          ${!isLogin ? `
            <div>
              <label for="f_name" class="block text-sm font-medium text-slate-700 mb-1.5">Full name</label>
              <input id="f_name" type="text" required class="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-lg text-sm" placeholder="Jane Cooper">
            </div>
            <div>
              <label for="f_org" class="block text-sm font-medium text-slate-700 mb-1.5">Organization name</label>
              <input id="f_org" type="text" required class="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-lg text-sm" placeholder="Acme Inc.">
              <p class="text-xs text-slate-500 mt-1">First user of an organization becomes admin.</p>
            </div>
          ` : ''}
          <div>
            <label for="f_email" class="block text-sm font-medium text-slate-700 mb-1.5">Email</label>
            <input id="f_email" type="email" required class="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-lg text-sm" placeholder="you@company.com">
          </div>
          <div>
            <label for="f_password" class="block text-sm font-medium text-slate-700 mb-1.5">Password</label>
            <input id="f_password" type="password" required minlength="4" class="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-lg text-sm" placeholder="••••••••">
          </div>
          <button type="submit" id="authSubmit" class="w-full btn-primary py-2.5 rounded-lg text-sm font-semibold flex items-center justify-center gap-2 transition">
            <span>${isLogin ? 'Sign in' : 'Create account'}</span>
            <i data-lucide="arrow-right" class="w-4 h-4"></i>
          </button>
        </form>
        <div class="mt-6 text-center text-sm text-slate-600">
          ${isLogin
            ? `New here? <button id="toSignup" class="text-violet-600 font-semibold hover:text-violet-700">Create an organization</button>`
            : `Already have an account? <button id="toLogin" class="text-violet-600 font-semibold hover:text-violet-700">Sign in</button>`}
        </div>
      </div>
    </div>
  </div>`;
}

function bindAuth() {
  const form = document.getElementById('authForm');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('f_email').value.trim().toLowerCase();
    const password = document.getElementById('f_password').value;
    const btn = document.getElementById('authSubmit');
    btn.disabled = true;
    btn.innerHTML = '<i data-lucide="loader-2" class="w-4 h-4 animate-spin"></i> Please wait...';
    lucide.createIcons();

    if (state.route === 'login') {
      const user = users().find(u => u.email === email && u.password === password);
      if (!user) {
        toast('Invalid email or password', 'error');
        btn.disabled = false;
        btn.innerHTML = 'Sign in <i data-lucide="arrow-right" class="w-4 h-4"></i>';
        lucide.createIcons();
        return;
      }
      state.currentUser = user;
      localStorage.setItem('taskflow_user', JSON.stringify(user)); // Save user session
      state.route = 'app';
      state.view = 'dashboard';
      toast(`Welcome back, ${user.name}`);
      render();
    } else {
      const name = document.getElementById('f_name').value.trim();
      const org  = document.getElementById('f_org').value.trim();
      if (users().some(u => u.email === email)) {
        toast('An account with that email already exists', 'error');
        btn.disabled = false;
        btn.innerHTML = 'Create account <i data-lucide="arrow-right" class="w-4 h-4"></i>';
        lucide.createIcons();
        return;
      }
      const isFirstInOrg = !users().some(u => u.org.toLowerCase() === org.toLowerCase());
      const newUser = {
        type: 'user', email, password, name, org,
        role: isFirstInOrg ? 'admin' : 'member',
        createdAt: new Date().toISOString(),
      };
      await window.dataSdk.create(newUser);
      
      state.currentUser = users().find(u => u.email === email) || newUser;
      localStorage.setItem('taskflow_user', JSON.stringify(state.currentUser)); // Save user session
      state.route = 'app';
      state.view = 'dashboard';
      toast(`Workspace created for ${org}`);
      render();
    }
  });

  document.getElementById('toSignup')?.addEventListener('click', () => { state.route = 'signup'; render(); });
  document.getElementById('toLogin')?.addEventListener('click',  () => { state.route = 'login';  render(); });
}

/* ---------- App Shell ---------- */
function renderApp() {
  const u = state.currentUser;
  const initials = (u.name || u.email).split(' ').map(s=>s[0]).slice(0,2).join('').toUpperCase();
  return `
  <div class="h-full w-full flex bg-slate-50">
    ${state.sidebarOpen ? '<div id="overlay" class="fixed inset-0 bg-black/40 z-30 lg:hidden"></div>' : ''}
    <aside class="${state.sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 fixed lg:static inset-y-0 left-0 w-64 z-40 transition-transform text-slate-200 flex flex-col" style="background: #0f172a;">
      <div class="p-5 border-b border-white/10">
        <div class="flex items-center gap-2.5">
          <div class="w-9 h-9 rounded-lg bg-violet-500 flex items-center justify-center">
            <i data-lucide="check-circle-2" class="w-5 h-5 text-white"></i>
          </div>
          <div>
            <div class="text-white font-bold text-sm">${escapeHtml(CONFIG.app_name)}</div>
            <div class="text-xs text-slate-400 truncate max-w-[150px]">${escapeHtml(u.org)}</div>
          </div>
        </div>
      </div>
      <nav class="flex-1 py-4 overflow-y-auto">
        ${[
          ['dashboard','layout-dashboard','Dashboard'],
          ['tasks','check-square','Tasks'],
          ['activity','activity','Activity'],
          ['profile','user','Profile'],
        ].map(([v,ic,lbl]) => `
          <button data-view="${v}" class="sidebar-item ${state.view===v?'active':''} w-full flex items-center gap-3 px-5 py-2.5 text-sm font-medium text-slate-400 hover:text-white hover:bg-white/5 border-l-2 border-transparent transition">
            <i data-lucide="${ic}" class="w-4 h-4"></i>
            <span>${lbl}</span>
            ${v==='tasks' ? `<span class="ml-auto bg-white/10 text-xs px-2 py-0.5 rounded-full mono">${orgTasks().length}</span>` : ''}
          </button>
        `).join('')}
      </nav>
      <div class="p-4 border-t border-white/10">
        <div class="flex items-center gap-3 px-2 py-2">
          <div class="w-9 h-9 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center text-white text-xs font-bold">${initials}</div>
          <div class="flex-1 min-w-0">
            <div class="text-sm text-white font-medium truncate">${escapeHtml(u.name)}</div>
            <div class="text-xs text-slate-400 flex items-center gap-1">
              ${u.role === 'admin' ? '<span class="text-violet-400">● Admin</span>' : '<span>● Member</span>'}
            </div>
          </div>
        </div>
        <button id="logoutBtn" class="mt-2 w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-400 hover:text-white hover:bg-white/5 rounded-md transition">
          <i data-lucide="log-out" class="w-4 h-4"></i> Sign out
        </button>
      </div>
    </aside>
    <div class="flex-1 flex flex-col min-w-0 overflow-hidden">
      <header class="bg-white border-b border-slate-200 px-4 lg:px-8 py-4 flex items-center justify-between">
        
        <div class="flex items-center gap-3">
          <button id="menuBtn" class="lg:hidden p-2 hover:bg-slate-100 rounded-md"><i data-lucide="menu" class="w-5 h-5"></i></button>
          <div>
            <div class="text-xs text-slate-500 uppercase tracking-wide mono">${escapeHtml(u.org)}</div>
            <h1 class="text-xl font-bold text-slate-900 capitalize">${state.view}</h1>
          </div>
        </div>
        
        <div class="flex items-center gap-3 sm:gap-4">
          <div class="flex items-center gap-1.5 px-2.5 py-1 rounded-md ${u.role === 'admin' ? 'bg-violet-50 text-violet-700 border border-violet-100' : 'bg-slate-100 text-slate-700 border border-slate-200'}">
            <div class="w-1.5 h-1.5 rounded-full ${u.role === 'admin' ? 'bg-violet-500' : 'bg-slate-500'}"></div>
            <span class="text-xs font-bold uppercase tracking-wider">${escapeHtml(u.role)}</span>
          </div>

          ${state.view === 'tasks' ? `
            <button id="newTaskTop" class="btn-primary px-3 lg:px-4 py-2 rounded-lg text-sm font-semibold flex items-center gap-2">
              <i data-lucide="plus" class="w-4 h-4"></i>
              <span class="hidden sm:inline">New task</span>
            </button>
          ` : ''}
        </div>

      </header>
      <main class="flex-1 overflow-auto p-4 lg:p-8">
        <div class="fade-in">
          ${renderView()}
        </div>
      </main>
    </div>
    ${state.showModal ? renderModal() : ''}
  </div>
  `;
}

function renderView() {
  switch (state.view) {
    case 'dashboard': return renderDashboard();
    case 'tasks':     return renderTasks();
    case 'activity':  return renderActivity();
    case 'profile':   return renderProfile();
  }
  return '';
}

function renderDashboard() {
  const all = orgTasks();
  const mine = all.filter(t => t.createdByEmail === state.currentUser.email);
  const completed = all.filter(t => t.status === 'completed').length;
  const pending = all.filter(t => t.status === 'pending').length;
  const recentLogs = orgLogs().slice(0, 5);
  const recentTasks = all.sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)).slice(0,4);
  const progress = all.length ? Math.round((completed / all.length) * 100) : 0;

  const stats = [
    { label:'Total tasks', value: all.length, icon:'inbox', color:'slate' },
    { label:'Completed', value: completed, icon:'check-circle-2', color:'emerald' },
    { label:'Pending', value: pending, icon:'clock', color:'amber' },
    { label:'My tasks', value: mine.length, icon:'user', color:'violet' },
  ];

  return `
  <div class="max-w-7xl mx-auto space-y-6">
    <div>
      <h2 class="text-2xl font-bold text-slate-900">Hello, ${escapeHtml(state.currentUser.name.split(' ')[0])} 👋</h2>
      <p class="text-slate-500 text-sm mt-1">Here's what's happening in ${escapeHtml(state.currentUser.org)} today.</p>
    </div>
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
      ${stats.map(s => `
        <div class="bg-white border border-slate-200 rounded-xl p-5 card-shadow">
          <div class="flex items-start justify-between mb-3">
            <div class="w-9 h-9 rounded-lg flex items-center justify-center bg-${s.color}-50 text-${s.color}-600">
              <i data-lucide="${s.icon}" class="w-4.5 h-4.5"></i>
            </div>
          </div>
          <div class="text-3xl font-bold text-slate-900 mono">${s.value}</div>
          <div class="text-xs text-slate-500 mt-1">${s.label}</div>
        </div>
      `).join('')}
    </div>
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div class="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-6 card-shadow">
        <div class="flex items-center justify-between mb-5">
          <div>
            <h3 class="text-sm font-semibold text-slate-900">Organization progress</h3>
            <p class="text-xs text-slate-500">Completion rate across all tasks</p>
          </div>
          <div class="text-2xl font-bold text-slate-900 mono">${progress}%</div>
        </div>
        <div class="h-2 bg-slate-100 rounded-full overflow-hidden mb-6">
          <div class="h-full rounded-full" style="width:${progress}%; background: linear-gradient(90deg,#8b5cf6,#6366f1);"></div>
        </div>
        <h4 class="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">Recent tasks</h4>
        <div class="space-y-2">
          ${recentTasks.length === 0 ? `
            <div class="text-center py-8 text-sm text-slate-400">
              <i data-lucide="inbox" class="w-8 h-8 mx-auto mb-2 text-slate-300"></i>
              No tasks yet. Create your first one!
            </div>
          ` : recentTasks.map(t => {
            const checklistProgress = t.checklist ? Math.round((t.checklist.filter(Boolean).length / 30) * 100) : 0;
            return `
            <div class="flex items-center gap-3 p-3 hover:bg-slate-50 rounded-lg transition">
              <div class="w-8 h-8 rounded-md flex items-center justify-center ${t.status==='completed'?'bg-emerald-50 text-emerald-600':'bg-amber-50 text-amber-600'}">
                <i data-lucide="${t.status==='completed'?'check':'clock'}" class="w-4 h-4"></i>
              </div>
              <div class="flex-1 min-w-0">
                <button data-view-task="${t.__backendId || t.id}" class="text-sm font-medium text-slate-900 truncate text-left w-full hover:text-violet-600 transition">${escapeHtml(t.title)}</button>
                <div class="text-xs text-slate-500">by ${escapeHtml(t.createdBy)} · ${fmtDate(t.createdAt)} · ${checklistProgress}% checked</div>
              </div>
              <span class="status-pill px-2 py-1 rounded-full ${t.status==='completed'?'bg-emerald-50 text-emerald-700':'bg-amber-50 text-amber-700'} font-medium uppercase">${t.status}</span>
            </div>
          `}).join('')}
        </div>
      </div>
      <div class="bg-white border border-slate-200 rounded-xl p-6 card-shadow">
        <div class="flex items-center justify-between mb-5">
          <h3 class="text-sm font-semibold text-slate-900">Recent activity</h3>
          <button data-view="activity" class="view-switch text-xs text-violet-600 font-medium hover:text-violet-700">View all</button>
        </div>
        ${recentLogs.length === 0 ? `
          <div class="text-center py-8 text-sm text-slate-400">
            <i data-lucide="activity" class="w-8 h-8 mx-auto mb-2 text-slate-300"></i>
            No activity yet.
          </div>
        ` : `
          <div class="space-y-4">
            ${recentLogs.map(l => `
              <div class="flex gap-3">
                <div class="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <i data-lucide="${logIcon(l.action)}" class="w-3.5 h-3.5 text-slate-600"></i>
                </div>
                <div class="flex-1 min-w-0">
                  <div class="text-sm text-slate-900"><span class="font-medium">${escapeHtml(l.actor)}</span> ${escapeHtml(l.action)}</div>
                  <div class="text-xs text-slate-500 truncate">${escapeHtml(l.target)} · ${fmtDate(l.createdAt)}</div>
                </div>
              </div>
            `).join('')}
          </div>
        `}
      </div>
    </div>
  </div>
  `;
}

function renderTasks() {
  const list = visibleTasks();
  const isAdmin = state.currentUser.role === 'admin';
  return `
  <div class="max-w-7xl mx-auto">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
      <div class="flex items-center gap-2 bg-white border border-slate-200 rounded-lg p-1 card-shadow w-fit">
        ${isAdmin ? `<button data-filter="all" class="filter-btn px-3 py-1.5 text-xs font-semibold rounded-md transition ${state.filter==='all'?'bg-slate-900 text-white':'text-slate-600 hover:bg-slate-50'}">All tasks</button>` : ''}
        <button data-filter="mine" class="filter-btn px-3 py-1.5 text-xs font-semibold rounded-md transition ${(!isAdmin||state.filter==='mine')?'bg-slate-900 text-white':'text-slate-600 hover:bg-slate-50'}">My tasks</button>
      </div>
      <div class="text-xs text-slate-500">
        Showing <span class="font-semibold text-slate-900 mono">${list.length}</span> ${list.length === 1 ? 'task' : 'tasks'}
      </div>
    </div>
    ${list.length === 0 ? `
      <div class="bg-white border border-dashed border-slate-300 rounded-xl p-12 text-center">
        <div class="w-14 h-14 mx-auto rounded-full bg-slate-100 flex items-center justify-center mb-4">
          <i data-lucide="clipboard-list" class="w-7 h-7 text-slate-400"></i>
        </div>
        <h3 class="text-base font-semibold text-slate-900">No tasks yet</h3>
        <p class="text-sm text-slate-500 mt-1 mb-5">Create your first task to get started.</p>
        <button id="newTaskEmpty" class="btn-primary px-4 py-2 rounded-lg text-sm font-semibold inline-flex items-center gap-2">
          <i data-lucide="plus" class="w-4 h-4"></i> New task
        </button>
      </div>
    ` : `
      <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        ${list.map(t => renderTaskCard(t, isAdmin)).join('')}
      </div>
    `}
  </div>
  `;
}

function renderTaskCard(t, isAdmin) {
  const canEdit = isAdmin || t.createdByEmail === state.currentUser.email;
  const isCompleted = t.status === 'completed';
  const checklistProgress = t.checklist ? Math.round((t.checklist.filter(Boolean).length / 30) * 100) : 0;
  
  return `
    <div class="bg-white border border-slate-200 rounded-xl p-5 card-shadow hover:border-slate-300 transition group flex flex-col">
      <div class="flex items-start justify-between gap-3 mb-3">
        <span class="status-pill px-2 py-1 rounded-full font-medium uppercase ${isCompleted?'bg-emerald-50 text-emerald-700':'bg-amber-50 text-amber-700'}">${t.status}</span>
        ${canEdit ? `
          <div class="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition">
            <button data-edit="${t.__backendId || t.id}" class="p-1.5 hover:bg-slate-100 rounded-md" title="Edit"><i data-lucide="pencil" class="w-3.5 h-3.5 text-slate-600"></i></button>
            <button data-toggle="${t.__backendId || t.id}" class="p-1.5 hover:bg-slate-100 rounded-md" title="Toggle status"><i data-lucide="${isCompleted?'rotate-ccw':'check'}" class="w-3.5 h-3.5 text-slate-600"></i></button>
            <button data-delete="${t.__backendId || t.id}" class="p-1.5 hover:bg-rose-50 rounded-md" title="Delete"><i data-lucide="trash-2" class="w-3.5 h-3.5 text-rose-600"></i></button>
          </div>
        ` : ''}
      </div>
      <button data-view-task="${t.__backendId || t.id}" class="text-left font-semibold text-slate-900 leading-snug mb-1.5 hover:text-violet-600 transition ${isCompleted?'line-through text-slate-400':''}">${escapeHtml(t.title)}</button>
      <div class="w-full bg-slate-100 h-1.5 rounded-full mb-3 overflow-hidden">
        <div class="bg-violet-500 h-full rounded-full" style="width: ${checklistProgress}%"></div>
      </div>
      <p class="text-sm text-slate-600 line-clamp-3 mb-4 flex-1">${escapeHtml(t.description || '—')}</p>
      <div class="flex items-center justify-between pt-3 border-t border-slate-100 text-xs text-slate-500">
        <div class="flex items-center gap-2">
          <div class="w-5 h-5 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center text-[9px] text-white font-bold">
            ${t.createdBy.split(' ').map(s=>s[0]).slice(0,2).join('').toUpperCase()}
          </div>
          <span class="font-medium text-slate-700">${escapeHtml(t.createdBy)}</span>
        </div>
        <span>${fmtDate(t.createdAt)}</span>
      </div>
    </div>
  `;
}

function renderActivity() {
  const list = orgLogs();
  return `
  <div class="max-w-3xl mx-auto">
    <div class="bg-white border border-slate-200 rounded-xl p-6 lg:p-8 card-shadow">
      <div class="flex items-center justify-between mb-6">
        <div>
          <h2 class="text-lg font-bold text-slate-900">Activity log</h2>
          <p class="text-sm text-slate-500">Recent actions across ${escapeHtml(state.currentUser.org)}</p>
        </div>
        <span class="status-pill px-2 py-1 rounded-full bg-slate-100 text-slate-700 font-medium mono">${list.length} events</span>
      </div>
      ${list.length === 0 ? `
        <div class="text-center py-12 text-sm text-slate-400">
          <i data-lucide="activity" class="w-10 h-10 mx-auto mb-3 text-slate-300"></i>
          No activity recorded yet.
        </div>
      ` : `
        <div class="relative pl-8">
          <div class="absolute left-3 top-2 bottom-2 w-px timeline-line"></div>
          ${list.map(l => `
            <div class="relative mb-5 last:mb-0">
              <div class="absolute -left-8 top-0 w-7 h-7 rounded-full bg-white border-2 border-slate-200 flex items-center justify-center">
                <i data-lucide="${logIcon(l.action)}" class="w-3.5 h-3.5 text-slate-600"></i>
              </div>
              <div class="bg-slate-50 rounded-lg p-3.5">
                <div class="text-sm text-slate-900">
                  <span class="font-semibold">${escapeHtml(l.actor)}</span> ${escapeHtml(l.action)} <span class="font-medium text-slate-700">"${escapeHtml(l.target)}"</span>
                </div>
                <div class="text-xs text-slate-500 mt-1 flex items-center gap-1.5">
                  <i data-lucide="clock" class="w-3 h-3"></i>
                  ${fmtDate(l.createdAt)} · ${new Date(l.createdAt).toLocaleString()}
                </div>
              </div>
            </div>
          `).join('')}
        </div>
      `}
    </div>
  </div>
  `;
}

function renderProfile() {
  const u = state.currentUser;
  const initials = u.name.split(' ').map(s=>s[0]).slice(0,2).join('').toUpperCase();
  const myTasks = orgTasks().filter(t => t.createdByEmail === u.email);
  const completed = myTasks.filter(t=>t.status==='completed').length;

  return `
  <div class="max-w-3xl mx-auto space-y-6">
    <div class="bg-white border border-slate-200 rounded-xl p-6 lg:p-8 card-shadow">
      <div class="flex items-center gap-5">
        <div class="w-20 h-20 rounded-2xl bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center text-white text-2xl font-bold">${initials}</div>
        <div class="flex-1 min-w-0">
          <h2 class="text-xl font-bold text-slate-900 truncate">${escapeHtml(u.name)}</h2>
          <p class="text-sm text-slate-500 truncate">${escapeHtml(u.email)}</p>
          <div class="flex items-center gap-2 mt-2">
            <span class="status-pill px-2 py-1 rounded-full font-medium uppercase ${u.role==='admin'?'bg-violet-50 text-violet-700':'bg-slate-100 text-slate-700'}">${u.role}</span>
            <span class="status-pill px-2 py-1 rounded-full bg-slate-100 text-slate-700 font-medium uppercase">${escapeHtml(u.org)}</span>
          </div>
        </div>
      </div>
      <div class="grid grid-cols-3 gap-4 mt-6 pt-6 border-t border-slate-100">
        <div><div class="text-2xl font-bold text-slate-900 mono">${myTasks.length}</div><div class="text-xs text-slate-500">My tasks</div></div>
        <div><div class="text-2xl font-bold text-slate-900 mono">${completed}</div><div class="text-xs text-slate-500">Completed</div></div>
        <div><div class="text-2xl font-bold text-slate-900 mono">${myTasks.length - completed}</div><div class="text-xs text-slate-500">Pending</div></div>
      </div>
    </div>
    <div class="bg-white border border-slate-200 rounded-xl p-6 card-shadow">
      <h3 class="text-sm font-semibold text-slate-900 mb-4">Organization</h3>
      <div class="space-y-3 text-sm">
        <div class="flex justify-between py-2 border-b border-slate-100">
          <span class="text-slate-500">Workspace</span><span class="font-medium text-slate-900">${escapeHtml(u.org)}</span>
        </div>
        <div class="flex justify-between py-2 border-b border-slate-100">
          <span class="text-slate-500">Members</span><span class="font-medium text-slate-900 mono">${users().filter(x=>x.org===u.org).length}</span>
        </div>
        <div class="flex justify-between py-2">
          <span class="text-slate-500">Your role</span><span class="font-medium text-slate-900 capitalize">${u.role}</span>
        </div>
      </div>
    </div>
  </div>
  `;
}

/* ---------- The Completed Modal Element ---------- */
function renderModal() {
  // 1. Rendering the 30-Day Checklist View
  if (state.viewingTask) {
    const t = state.viewingTask;
    const completedDays = t.checklist ? t.checklist.filter(Boolean).length : 0;
    const progress = Math.round((completedDays / 30) * 100) || 0;

    return `
    <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 fade-in" id="modalBackdrop">
      <div class="bg-white rounded-xl shadow-xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div class="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <div class="flex-1 pr-4">
            <h3 class="text-xl font-bold text-slate-900 mb-1">${escapeHtml(t.title)}</h3>
            <div class="flex items-center gap-3">
              <div class="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden max-w-[200px]">
                <div class="h-full rounded-full bg-violet-500 transition-all duration-300" style="width: ${progress}%"></div>
              </div>
              <span class="text-sm font-semibold text-slate-600">${progress}% Complete</span>
            </div>
          </div>
          <button id="closeModal" class="p-1 text-slate-400 hover:bg-slate-100 rounded-md"><i data-lucide="x" class="w-5 h-5"></i></button>
        </div>
        <div class="p-6 overflow-y-auto bg-slate-50">
          <p class="text-sm text-slate-700 mb-6">${escapeHtml(t.description || 'No description provided.')}</p>
          
          <h4 class="text-sm font-semibold text-slate-900 mb-4">30-Day Checklist</h4>
          <div class="grid grid-cols-5 sm:grid-cols-6 md:grid-cols-10 gap-3">
            ${Array.from({length: 30}).map((_, i) => {
              const isChecked = t.checklist && t.checklist[i];
              return `
              <button data-toggle-day="${i}" class="aspect-square flex flex-col items-center justify-center rounded-lg border-2 transition-all duration-200 ${isChecked ? 'bg-violet-500 border-violet-500 text-white shadow-md transform scale-105' : 'bg-white border-slate-200 text-slate-400 hover:border-violet-300'}">
                <span class="text-[10px] font-bold uppercase mb-1">Day</span>
                <span class="text-lg font-bold">${i + 1}</span>
              </button>
              `;
            }).join('')}
          </div>
        </div>
      </div>
    </div>`;
  }

  // 2. Rendering the Edit/New Task Form
  const t = state.editingTask;
  const isEdit = !!t;
  return `
  <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 fade-in" id="modalBackdrop">
    <div class="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden relative" id="modalContent">
      <div class="flex items-center justify-between px-6 py-4 border-b border-slate-100">
        <h3 class="text-lg font-bold text-slate-900">${isEdit ? 'Edit task' : 'New task'}</h3>
        <button id="closeModal" class="p-1 text-slate-400 hover:bg-slate-100 rounded-md transition"><i data-lucide="x" class="w-5 h-5"></i></button>
      </div>
      <form id="taskForm" class="p-6 space-y-4">
        <div>
          <label class="block text-sm font-medium text-slate-700 mb-1.5">Title</label>
          <input id="t_title" type="text" required value="${isEdit ? escapeHtml(t.title) : ''}" class="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-lg text-sm" placeholder="What needs to be done?">
        </div>
        <div>
          <label class="block text-sm font-medium text-slate-700 mb-1.5">Description (optional)</label>
          <textarea id="t_desc" rows="3" class="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-lg text-sm" placeholder="Add more details...">${isEdit ? escapeHtml(t.description) : ''}</textarea>
        </div>
        <div class="flex justify-end gap-3 mt-6">
          <button type="button" id="cancelModal" class="px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-50 rounded-lg transition">Cancel</button>
          <button type="submit" id="saveTaskBtn" class="btn-primary px-4 py-2 rounded-lg text-sm font-semibold inline-flex items-center gap-2">
            <i data-lucide="check" class="w-4 h-4"></i> Save task
          </button>
        </div>
      </form>
    </div>
  </div>
  `;
}

/* ---------- App Events Integration ---------- */
function bindApp() {
  const appContainer = document.getElementById('app');

  // Clear previous listeners by replacing the node, then re-bind
  appContainer.replaceWith(appContainer.cloneNode(true));
  const newApp = document.getElementById('app');

  newApp.addEventListener('click', async (e) => {
    const targetBtn = e.target.closest('button, [data-view]');
    if (!targetBtn) {
      if (e.target.id === 'modalBackdrop') {
        state.showModal = false;
        state.viewingTask = null; // Clear view state
        render();
      }
      return;
    }

    // Sidebar navigation
    if (targetBtn.dataset.view) {
      state.view = targetBtn.dataset.view;
      state.sidebarOpen = false;
      render();
    }
    // Mobile menu toggle
    else if (targetBtn.id === 'menuBtn') {
      state.sidebarOpen = !state.sidebarOpen;
      render();
    }
    // Logout
    else if (targetBtn.id === 'logoutBtn') {
      state.currentUser = null;
      localStorage.removeItem('taskflow_user'); // Remove session on logout
      state.route = 'login';
      render();
    }
    // Task filters
    else if (targetBtn.dataset.filter) {
      state.filter = targetBtn.dataset.filter;
      render();
    }
    // Modal open (New Task)
    else if (targetBtn.id === 'newTaskTop' || targetBtn.id === 'newTaskEmpty') {
      state.editingTask = null;
      state.viewingTask = null;
      state.showModal = true;
      render();
    }
    // Modal close
    else if (targetBtn.id === 'closeModal' || targetBtn.id === 'cancelModal') {
      state.showModal = false;
      state.viewingTask = null;
      render();
    }
    // Task Edit (Pencil Icon)
    else if (targetBtn.dataset.edit) {
      const id = targetBtn.dataset.edit;
      state.editingTask = tasks().find(t => t.__backendId === id || t.id === id);
      state.viewingTask = null;
      state.showModal = true;
      render();
    }
    // View Task Checklist (Clicking Title)
    else if (targetBtn.dataset.viewTask) {
      const id = targetBtn.dataset.viewTask;
      state.viewingTask = tasks().find(t => t.__backendId === id || t.id === id);
      state.editingTask = null;
      state.showModal = true;
      render();
    }
    // Toggle a day on the 30-day checklist
    else if (targetBtn.dataset.toggleDay) {
      if (!state.viewingTask) return;
      const dayIndex = parseInt(targetBtn.dataset.toggleDay, 10);
      const id = state.viewingTask.__backendId || state.viewingTask.id;
      
      // Clone array and flip boolean
      const newChecklist = [...(state.viewingTask.checklist || Array(30).fill(false))];
      newChecklist[dayIndex] = !newChecklist[dayIndex];
      
      // Update UI optimistically
      state.viewingTask.checklist = newChecklist;
      
      // Save
      await window.dataSdk.update(id, { checklist: newChecklist });
      render();
    }
    // Mark complete/pending
    else if (targetBtn.dataset.toggle) {
      const id = targetBtn.dataset.toggle;
      const t = tasks().find(x => x.__backendId === id || x.id === id);
      if (t) {
        const newStatus = t.status === 'completed' ? 'pending' : 'completed';
        await window.dataSdk.update(id, { status: newStatus });
        await logActivity(`marked task as ${newStatus}`, t.title);
        toast(`Task marked as ${newStatus}`);
        render();
      }
    }
    // Delete task
    else if (targetBtn.dataset.delete) {
      const id = targetBtn.dataset.delete;
      const t = tasks().find(x => x.__backendId === id || x.id === id);
      if (confirm('Are you sure you want to delete this task?')) {
        await window.dataSdk.delete(id);
        await logActivity('deleted a task', t.title);
        toast('Task deleted', 'info');
        render();
      }
    }
  });

  // Handle Form Submission for tasks
  const form = document.getElementById('taskForm');
  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const title = document.getElementById('t_title').value.trim();
      const desc = document.getElementById('t_desc').value.trim();
      const btn = document.getElementById('saveTaskBtn');
      btn.disabled = true;
      btn.innerHTML = 'Saving...';

      if (state.editingTask) {
        const id = state.editingTask.__backendId || state.editingTask.id;
        await window.dataSdk.update(id, { title, description: desc });
        await logActivity('updated task', title);
        toast('Task updated');
      } else {
        const newTask = {
          type: 'task',
          title,
          description: desc,
          status: 'pending',
          checklist: Array(30).fill(false), // NEW: Init array for 30 days
          createdBy: state.currentUser.name,
          createdByEmail: state.currentUser.email,
          assignedOrg: state.currentUser.org,
          createdAt: new Date().toISOString()
        };
        await window.dataSdk.create(newTask);
        await logActivity('created a task', title);
        toast('Task created');
      }
      state.showModal = false;
      render();
    });
  }
}

// Initial Boot
document.addEventListener('DOMContentLoaded', () => {
  render();
});